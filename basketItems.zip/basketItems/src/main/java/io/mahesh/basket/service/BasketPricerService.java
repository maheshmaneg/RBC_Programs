package io.mahesh.basket.service;

import java.math.BigDecimal;

import io.mahesh.basket.domain.Basket;



public interface BasketPricerService {
	
	/**
	 * @param basket the basket to price
	 * @return basket total price
	 * @throws RuntimeException if unable to price any item
	 */
	BigDecimal priceBasket(Basket basket) throws RuntimeException;

}
