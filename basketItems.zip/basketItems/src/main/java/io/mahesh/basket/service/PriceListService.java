package io.mahesh.basket.service;

import java.util.Collection;

import io.mahesh.basket.domain.ItemPricing;



public interface PriceListService {

	Collection<ItemPricing> getPricesForItem(String itemId);
}
