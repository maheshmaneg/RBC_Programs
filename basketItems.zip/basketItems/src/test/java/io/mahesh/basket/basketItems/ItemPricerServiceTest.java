package io.mahesh.basket.basketItems;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import io.mahesh.basket.domain.ItemPricing;
import io.mahesh.basket.service.ItemPricerService;
import io.mahesh.basket.service.ItemPricerServiceImpl;
import io.mahesh.basket.service.PriceListService;


@RunWith(MockitoJUnitRunner.class)
public class ItemPricerServiceTest {
	
	@Mock
	PriceListService priceList;
	
	@Test
	public void should_price_item_correctly()
	{
		// define unit price for Orange, we may have other offers in the futur
		when(priceList.getPricesForItem("Orange")).thenReturn(Arrays.asList(new ItemPricing("Orange",new BigDecimal(30),1)));

		ItemPricerService pricer = new ItemPricerServiceImpl(priceList); 
		
		assertEquals("2 kg oranges 60 rs", new BigDecimal(30),  pricer.priceItem("Orange", 2).get() );
	
	}
	
	@Test
	public void should_price_item_choose_best_price_offer_correctly()
	{
		when(priceList.getPricesForItem("Orange")).thenReturn(Arrays.asList(new ItemPricing("Orange",new BigDecimal(30),1), new ItemPricing("Orange",new BigDecimal(30), 2)));
		ItemPricerService pricer = new ItemPricerServiceImpl(priceList); 
		assertEquals("3  kg oranges ", new BigDecimal(30),  pricer.priceItem("Orange", 3).get() );
	
	}


	@Test
	public void should_not_return_value_if_item_null()
	{
		when(priceList.getPricesForItem(null)).thenReturn(Collections.emptyList());
		ItemPricerService pricer = new ItemPricerServiceImpl(priceList); 
		assertFalse("No price available", pricer.priceItem(null, 3).isPresent() );
	
	}
}
