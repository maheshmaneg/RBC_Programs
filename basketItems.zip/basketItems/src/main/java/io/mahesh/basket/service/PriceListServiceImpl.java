package io.mahesh.basket.service;

import java.util.Collection;
import java.util.stream.Collectors;



import io.mahesh.basket.domain.ItemPricing;

public class PriceListServiceImpl implements PriceListService {

	private Collection<ItemPricing> offers;
	
	public PriceListServiceImpl(Collection<ItemPricing> staticData)
	{
		offers = staticData;
	}
	
	

	public Collection<ItemPricing> getPricesForItem(String itemId)
	{
		return offers.stream().filter(offer -> offer.getItemId().equals(itemId)).collect(Collectors.toList());
	}
}
