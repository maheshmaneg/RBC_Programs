package io.mahesh.basket.domain;

import java.math.BigDecimal;


public class ItemPricing {
	
	private String itemId;
	private BigDecimal price;
	private Integer quantity;
	private BigDecimal pricePerUnit;
	
	public ItemPricing(String id, BigDecimal price, Integer quantity) {
		super();
		this.itemId=id;
		this.price = price;
		this.quantity = quantity;
		this.pricePerUnit = price.divide(new BigDecimal(quantity));
	}
	
	public String getItemId() {
		return itemId;
	}

	public BigDecimal getPrice() {
		return price;
	}
	
	public Integer getQuantity() {
		return quantity;
	}
	
	public BigDecimal getPricePerUnit() {
		return pricePerUnit;
	}
	
}
