package io.mahesh.basket.basketItems;

import java.math.BigDecimal;
import java.util.Arrays;

import io.mahesh.basket.domain.Basket;
import io.mahesh.basket.domain.ItemPricing;
import io.mahesh.basket.service.BasketPricerService;
import io.mahesh.basket.service.BasketPricerServiceImpl;
import io.mahesh.basket.service.ItemPricerServiceImpl;
import io.mahesh.basket.service.PriceListService;
import io.mahesh.basket.service.PriceListServiceImpl;


public class BasketApp 
{
    public static void main( String[] args )
    {
            
    	//Apple Orange Orange Banana
		//Defined Rates in KG for Items
		  PriceListService prices = new
		  PriceListServiceImpl(Arrays.asList( new
		  ItemPricing("Banana",new BigDecimal(20),1), new ItemPricing("Orange",new
		  BigDecimal(30),1), new ItemPricing("Apple",new BigDecimal(100),1), new
		  ItemPricing("Lemon",new BigDecimal(10),1), new ItemPricing("Peache",new
		  BigDecimal(50),1) ));
		 
        //Banana Orange Apple Lemon Peache	
		  BasketPricerService service = new BasketPricerServiceImpl(new ItemPricerServiceImpl(prices));
        
        Basket basket = new Basket(args);
        try {
        System.out.println("Your Basket Price is " +service.priceBasket(basket)+" Rs");
        }catch(IllegalArgumentException exc)
        {
        	System.out.println("Data input is invalide");
        	exc.printStackTrace();
        }
        catch(RuntimeException e)
        {
        	 System.out.println("System was unable to price one or few elements in the basket ");
        	 e.printStackTrace();
        }
        		
    }
}