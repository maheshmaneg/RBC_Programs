package io.mahesh.basket.service;

import java.math.BigDecimal;
import java.util.Optional;

public interface ItemPricerService {
	
	

	Optional<BigDecimal> priceItem(String itemId, int quantity);

}
