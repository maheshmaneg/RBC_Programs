package io.mahesh.basket.basketItems;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import io.mahesh.basket.domain.Basket;
import io.mahesh.basket.domain.ItemPricing;
import io.mahesh.basket.service.BasketPricerService;
import io.mahesh.basket.service.BasketPricerServiceImpl;
import io.mahesh.basket.service.ItemPricerService;
import io.mahesh.basket.service.ItemPricerServiceImpl;
import io.mahesh.basket.service.PriceListService;


@RunWith(MockitoJUnitRunner.class)
public class BasketPricerServiceTest {
	
	@Mock
	PriceListService priceList;
	
	ItemPricerService itemPricer; 
	
	BasketPricerService basketPricer ; 
	
	@Before
	public void setUp()
	{
		MockitoAnnotations.initMocks(this);
		// define unit price for Orange, and a discounted price for 2 oranges
		when(priceList.getPricesForItem("Orange")).thenReturn(Arrays.asList(new ItemPricing("Orange",new BigDecimal(30),1), new ItemPricing("Orange",new BigDecimal(30), 2)));
		when(priceList.getPricesForItem("Apple")).thenReturn(Arrays.asList(new ItemPricing("Apple",new BigDecimal(100),1)));
		when(priceList.getPricesForItem(null)).thenReturn(Arrays.asList());
		itemPricer = new ItemPricerServiceImpl(priceList); 
		basketPricer = new BasketPricerServiceImpl(itemPricer); 
		
	}
	
	@Test
	public void should_price_item_correctly()
	{
		Basket basket = new Basket("Apple");
		assertEquals("1 kg Apple for worth 100 ", new BigDecimal(100), basketPricer.priceBasket(basket));
	
	}
	
	
	@Test(expected=RuntimeException.class)
	public void should_not_return_value_if_no_price_found()
	{
		// Pear price not found !!
		Basket basket = new Basket("Orange","Pear");
		basketPricer.priceBasket(basket);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void should_not_return_value_if_item_null()
	{
		Basket basket = new Basket(null);
		basketPricer.priceBasket(basket);
	}
}
